<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (file_exists(SYSTEMPATH . 'Config/Routes.php'))
{
	require SYSTEMPATH . 'Config/Routes.php';
}

/**
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Blog');
$routes->setDefaultMethod('homepage');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
// * Admin/Mitra/List 

// $routes->add('/', 'Home::index'); Change this if it is complete



$routes->get('/admin/mitra/', 'Admin\Mitra::list'); // Mitra Home
$routes->get('/admin/mitra/ajax-list/(:any)', 'Admin\Mitra::ajax_list/$1');
$routes->get('/admin/mitra/ajax-single', 'Admin\Mitra::ajax_list/');
$routes->get('/admin/mitra/(:any)', 'Admin\Mitra::$1'); // Mitra Re-route method

$routes->get('/admin', 'Admin\Dashboard::index'); // Dashboard
$routes->get('/admin/dashboard/', 'Admin\Dashboard::index'); // Dashboard Re-route method
$routes->get('/admin/dashboard/(:any)', 'Admin\Dashboard::$1'); // Dashboard Re-route method

$routes->get('/admin/pengguna/', 'Admin\Admin::list'); // Admin Re-route method
$routes->post('/admin/pengguna/', 'Admin\Admin::remove'); // Admin Re-route method
$routes->get('/admin/pengguna/(:any)', 'Admin\Admin::$1'); // Admin Re-route method


$routes->get('/admin/postingan/', 'Admin\Artikel::list'); // Postingan Artikel Re-route method

$routes->get('/admin/postingan/artikel/', 'Admin\Artikel::list'); // Postingan Artikel Re-route method
$routes->get('/admin/postingan/artikel/(:any)', 'Admin\Artikel::$1'); // Postingan Artikel Re-route method

$routes->get('/admin/postingan/halaman/', 'Admin\Halaman::list'); // Postingan Halaman Re-route method
$routes->get('/admin/postingan/halaman/(:any)', 'Admin\Halaman::$1'); // Postingan Halaman Re-route method

$routes->get('/admin/tataletak/', 'Admin\TataLetak::homepage'); // Tataletak Index page
$routes->get('/admin/tataletak/(:any)', 'Admin\TataLetak::$1'); // Tataletak Pages

$routes->get('/admin/konfigurasi/', 'Admin\Konfigurasi::index'); // Tataletak Index page
$routes->get('/admin/konfigurasi/(:any)', 'Admin\Konfigurasi::$1'); // Tataletak Pages

$routes->get('/login', 'Admin\Auth::index');
$routes->post('/login', 'Admin\Auth::do_login');
$routes->get('/logout', 'Admin\Auth::logout');

$routes->get('/mitra', 'Mitra::list'); // Front-end Mitra (Cari Mitra);

// $routes->get('/mitra', 'Mitra::index'); // Front-end Mitra (Cari Mitra); Change this if it is complete
$routes->get('/mitra/list', 'Mitra::list'); // Front-end Mitra (List pencarian Mitra);
$routes->get('/mitra/ajax_list/(:segment)', 'Mitra::ajax_list/$1'); // Front-end Mitra (List pencarian Mitra);
$routes->get('/mitra/dynamic_form_kelurahan', 'Mitra::dynamic_form_kelurahan'); // Front-end Mitra (List pencarian Mitra);
$routes->get('/mitra/(:any)', 'Mitra::detail/$1'); // Front-end Mitra (Detail Mitra);

$routes->get('/', 'Blog::homepage');
$routes->get('/terkini', 'Blog::terkini');
$routes->get('/terpopuler', 'Blog::terpopuler');
$routes->get('/kategori/(:any)', 'Blog::kategori/$1');
$routes->get('/penulis/(:any)', 'Blog::penulis/$1');
$routes->get('/halaman/(:segment)', 'Blog::detail_halaman/$1');
$routes->get('/(:segment)', 'Blog::detail_artikel/$1');
/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php'))
{
	require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
