<?php namespace config;

use \CodeIgniter\Config\BaseConfig;

class Upload extends BaseConfig {
	public $directoryPublic = ROOTPATH . 'public/';
	
	public $directoryMitraGaleri = ROOTPATH . 'public/images/mitra/galeri';
	public $directoryMitraArtikel = ROOTPATH . 'public/images/mitra';
	public $directoryMitraArtikelFile = ROOTPATH . 'public/files/mitra';

	public $directoryAdminAvatar = ROOTPATH . 'public/images/profile';

	public $directoryArtikelGambar = ROOTPATH . 'public/images/postingan/artikel';
	public $directoryArtikelFile = ROOTPATH . 'public/files/postingan/artikel';
	
	public $directoryHalamanGambar = ROOTPATH . 'public/images/postingan/halaman';
	public $directoryHalamanFile = ROOTPATH . 'public/files/postingan/halaman';
}
?>